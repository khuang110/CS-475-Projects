#pragma once
// Helper functions
float Ranf(float low, float high);
int Ranf(int ilow, int ihigh);
void TimeOfDaySeed();
void HandleArgs(int argc, char* argv[], int& Numt, int& NumTrials);